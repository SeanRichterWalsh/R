# INTRODUCTION TO R AND DATA VISUALISATION
# Venue: Aon Centre for Innovation and Analytics
# Date: 26 March 2019
# Author: Sean Walsh
# Contact: sdwalsh335@gmail.com


###########################################################################
## INTRODUCTION SLIDESHOW (10 min)
###########################################################################

# Present slideshow.

###########################################################################
## RSTUDIO FAMILIARISATION (15 min)
###########################################################################

# RStudio is the integrated development environment (IDE) for an R-based data science workflow. R scripts
# can be written, code can be run and tested, data visualisation can be carried out, interaction with the 
# native operating system is possible via the terminal panel, connections can be made to databases, data can be
# imported, slide presentations and dashboards can be created, R Markdown reports/notebooks can be rendered, file 
# systems can be viewed and, most importantly, STATISTICAL WORK can be conducted with ease.


###########################################################################
## PART 1: BASE R FUNDAMENTALS AND SOME BASIC FUNCTIONS (40 min)
###########################################################################

# I will attempt to keep this workshop as "workshop" as possible (i.e. running code and going through the output).
# The best starting point for learning R is understanding the various data types and structures. In R, we have integer, 
# numeric, character, logical and factor data types (atomic vector types). Dates are another data type in R and can be 
# stored in an number of formats. Increasing in complexity, R has table, matrix, dataframe and list data structures.

# Continuous: numeric
# Discrete: integer
# Categorical: factor (ordinal/nominal), logical (Boolean), binary numeric/integer
# String/text: character
# Dates: POSIXct, POSIXlt, yearmon and Date are examples of some date data types

# Create vectors of the different data types (these are known as atomic vectors in R)
# Note the use of spacing and new lines in my R code (best practice as it enhances code readability)
# http://adv-r.had.co.nz/Style.html

# integer (discrete)
x <- 6 # Note the assignment operator <- (never use = as this should be kept for mathematical operations and function arguments)
x <- 1:10 
1:10 -> x
print(x)
x
class(x)

# numeric (continuous)
y <- rnorm(10)
?rnorm
class(y)

# character
my_name <- "Sean Walsh"
class(my_name)

# logical
i_like_science <- TRUE
i_like_science <- T # Save some typing?
class(i_like_science)

# factors
my_colours <- c("red",
                "green",
                "blue")

class(my_colours)

factor(my_colours) # Convert the character vector to a factor
class(factor(my_colours))

my_colours <- factor(my_colours) # Nominal? Is there an order?
class(my_colours)

wavelength <- factor(c("red",
                       "green",
                       "blue"),
                     ordered = T) # If the colours have a meaningful order

levels(wavelength)
wavelength

# Conversion functions
as.numeric()
as.integer()
as.character()
as.factor()
factor()
as.Date()
as.POSIXct()
as.POSIXlt()
as.table()
as.matrix()
as.data.frame()
as.list()

# Question functions
is.integer(y)
is.character(i_like_science)
is.numeric(y)
is.logical(i_like_science)
is.factor(wavelength)
is.data.frame()
is.matrix()
is.table()
is.list()

# Now that we have seen the main atomic vector types used by R, how are they represented in more 
# complex data structures such as matrices, tables, dataframes and lists?

# Create a matrix with the elements of x which we created earlier
# Linear algebra can be performed on matrices just like it is in mathematics
sales <- matrix(x,
                ncol = 5,
                byrow = T)

sales 

# Operations are performed element-wise
sales + 76
sales ^ 2
sales / 2
sales * 10
sales - 1
sales + sales
sales - sales

sales

rownames(sales) <- c("Week1", "Week2")
sales
colnames(sales) <- c("Mon", "Tue", "Wed", "Thu", "Fri")
sales 
class(sales)

# Indexing in R using square brackets (dplyr offers a more SQL-type of querying)
sales[1, 3]
sales[2, "Fri"]
sales["Week2", "Tue"]
sales[ , "Mon"]
sales["Week1", ]

# R has many vectorised operations which means that they occur in parallel in particular R objects.
# For example, the addition of two vectors is a vectorised operation:
x + y

# In fact, R can be used as a calculator with all operations being vectorised:
6 + 7
2 ^ 4
2 * 5
2 - 1
2 / 0.5
2 %% 1
sqrt(16)

# Data can be tabulated quickly using the table() function
table(my_colours)
class(table(my_colours))

data(mtcars) # mtcars is a built-in data set part of the R software
table(mtcars$cyl)
table("No. of cylinders" = mtcars$cyl)
nrow(mtcars)
ncol(mtcars)
dim(mtcars)
str(mtcars)
head(mtcars, 10)

# Dataframes are different to matrices in that they can contain various types of atomic vector
# Matrices are restricted to having just one atomic vector type per matrix (but matrices can be made up of any vector type)
class(mtcars)
?mtcars

# Dataframes can be indexed in the same way as matrices (i.e. row-then-column)
mtcars[1, 2]
mtcars[1, 2:6]
mtcars[1, c(2, 4, 6)]
mtcars[1, "mpg"]
mtcars["mpg"]

mtcars$car <- rownames(mtcars)
head(mtcars)

mtcars["Hornet Sportabout", c("hp", "mpg", "wt")]

# Lists are a little complex but really useful when working with big data
# Example: a function which imports 57,000 CSV files into a list (lapply() is an example)
# The imported dataframes could then be analysed individually or appended together
my_list <- list(abc = letters,
                ten2fifty = 10:50,
                cars = mtcars,
                my_pref = i_like_science,
                light = wavelength,
                x = x,
                y = y,
                another_list = list(x = x,
                                    y = y,
                                    light = wavelength))

class(my_list)
names(my_list)

# Indexing lists is a little different too
my_list[1]
my_list[[1]]

my_list[[1]][5]
my_list[["cars"]]["mpg"]
my_list[["another_list"]][["light"]][1]

my_list$cars
my_list$cars$mpg
my_list$another_list

sapply(my_list, class)
sapply(my_list, is.data.frame)

# That was a brief introduction to R's atomic vector types and data structures. There is obviously far
# more to cover but this should provide a good starting point for your own R learning journey. Practice
# makes perfect! The only way to get good at coding and statistical analysis is to do plenty of coding
# and statistical analysis. A great place to learn is https://www.datacamp.com/ and some good books are
# any of the series on R by Michael J. Crawley and R for Data Science by Grolemund and Wickham.

# Entering the realm of statistics a little.....
# summary() is an incredibly useful function for inspecting R objects (lists, matrices, dataframes, models, plots, vectors, etc.)
summary(mtcars)
summary(my_list)
summary(sales)
summary(y)

# Measures of central tendency
mean(mtcars$mpg)
median(mtcars$mpg)
mean(mtcars$mpg,
     trim = 0.1)

# Measures of spread
min(mtcars$mpg)
max(mtcars$mpg)
IQR(mtcars$mpg)
var(mtcars$mpg)
sd(mtcars$mpg)
sqrt(var(mtcars$mpg))

# Pearson's correlation test
cor(mtcars$hp,
    mtcars$mpg)

# Using functions within indexing
mtcars[which(mtcars$hp == max(mtcars$hp)), ]


###########################################################################
## PART 2: DATA VISUALISATION WITH R (45 min) 
###########################################################################

# Data visualisation can create a bridge between data scientists and business management. Results and concepts can
# be explained with effective data visualisations and R is top of the pile when it comes to this. I will introduce
# base R plotting as well as the excellent ggplot2 package before moving on to some interactive data visualisation 
# examples which utilise variouse excellent R packages such as dygraphs and networkD3 (which are both JavaScript
# plotting libraries).

# What is ggplot2? The Grammar of Graphics is based on three core components: a dataframe, aesthetic mapping, and geometric shapes for the mapping.
# Install (if necessary) and load the packages and data needed for this section:

# Load packages (knitr and rmarkdown should be installed by default)
library(ggplot2)
library(dplyr)
library(dygraphs)
library(ggcorrplot)
library(readxl)
library(networkD3)

# Package developers
citation("ggplot2")
citation("dplyr")

# diamonds data set
data("diamonds")
?diamonds

# mtcars data set
data("mtcars")
?mtcars

# Data are often stored in MS Excel spreadsheets and the readxl package can be used for import
# I am using an absolute pathway to the test data so you will need to adjust this for your own machine 
churn_xlsx <- read_excel("/home/swalsh/test_dfXLSX.xlsx", 
                         sheet = 1, # Sheet index can be specified using position or name
                         col_names = T)

# CSV files can also be imported easily
# Unlike Excel files, multiple sheets are not permitted.
churn_csv <- read.csv("/home/swalsh/test_dfCSV.csv",
                      stringsAsFactors = F)


## VISUALISING UNIVARIATE DATA

# The best graphical methods for visualising univariate distributions tend to be histograms, density plots and index plots. 
# We want to investigate the shape of the data and also identify any potential anomalies or outliers. 
# Knowing the shape of data samples is highly important when making statistical inferences, performing statistical modelling and 
# testing hypotheses. These plot types are the bread and butter of statisticians.

# Basic histogram (R sets the binwidth by default)
# binwidth = range / n desired bins
ggplot(data = diamonds, 
       aes(x = price)) +
  geom_histogram()

# Base R version of the histogram ("off the shelf")
hist(diamonds$price)

# Natural log (ln) transform the x-axis variable 
# Transformations can be done within the ggplot framework
ggplot(data = diamonds, 
       aes(x = log(price))) +
  geom_histogram()

# Arithmetic operations can also be performed within the ggplot framework 
ggplot(data = diamonds, 
       aes(x = price / carat)) + # Price per carat
  geom_histogram(bins = 25) +
  xlab("price per carat ($)")

# Basic density plot (plots the probability density function)
ggplot(data = diamonds, 
       aes(x = price)) +
  geom_density(adjust = 0.5) # The kernel smoothness can be adjusted 

# Which is the same as
density(diamonds$price) %>% 
  plot()

# Base R version
plot(density(diamonds$price),
     main = "Most probable diamond prices",
     xlab = "price ($)")

# Index plots are useful for spotting outliers or anomalies
plot(mtcars$hp) 

# Variance about the mean
plot(mtcars$hp)
abline(h = mean(mtcars$hp, na.rm = T),
       col = "red")

# Mark potential outliers
# Outlier definition: [Q1 - 1.5 * IQR, Q3 + 1.5 * IQR]
hp_iqr <- IQR(mtcars$hp)
lower <- quantile(mtcars$hp, 0.25) - (1.5 * hp_iqr) 
upper <- quantile(mtcars$hp, 0.75) + (1.5 * hp_iqr)

plot(mtcars$hp,
     pch = 21,
     bg = if_else(mtcars$hp >= upper | mtcars$hp <= lower, "red", "black"), # Inspect data if outliers are present
     main = "Gross horsepower index plot with outliers",
     ylab = "hp") 

# So far we have been considering univariate continuous data but we can also have categorical data in univariate analysis
# Categorical data in R are usually stored as factors and can be ordinal or nominal

# We can use a barplot to visualise the frequency of the ordered factor cut in the diamonds data
# ggplot makes use of the inherent ordering when plotting the bars
ggplot(data = diamonds,
       aes(x = cut)) +
  geom_bar()

# We can also build a radar plot and customise a little
ggplot(data = diamonds,
       aes(x = cut)) +
  geom_bar(fill = "#00306A",
           colour = "white") +
  ggtitle("Diamond cut type",
          subtitle = "Source: ggplot2::diamonds data set") +
  xlab(" ") +
  coord_polar() +
  theme_minimal() +  # Different look/theme
  theme(text = element_text(face = "bold",
                            family = "AvantGarde")) 


## VISUALISING BIVARIATE DATA

# When exploring bivariate data, typical visualisations used are scatter plots, column plots and boxplots.
# Boxplots are great for comparing the distributions of single or multiple samples 

# Basic scatter plot
ggplot(data = diamonds, 
       aes(x = carat,
           y = price)) +
  geom_point()

# Overplotting can be solved using the transparency setting and jitter (random noise)
# Warning! Jitter will slightly alter the actual values when plotting so it is useful for identifying patterns only
ggplot(data = diamonds, 
       aes(x = carat,
           y = price)) +
  geom_jitter(alpha = 0.2) +
  ggtitle("The relationship between diamond price and carat",
          subtitle = "Source: ggplot2::diamonds data set")

# Boxplots to compare different samples
ggplot(data = diamonds, 
       aes(x = cut, # Categorical data on x-axis
           y = price)) +
  geom_boxplot()

# Boxplots without outliers (outlier definition: [Q1 - 1.5 * IQR, Q3 + 1.5 * IQR])
ggplot(data = diamonds, 
       aes(x = cut,
           y = price)) +
  geom_boxplot(outlier.shape = NA,
               width = 0.25,
               fill = "lavender") +
  theme_bw()

# Flipping axes
ggplot(data = diamonds, 
       aes(x = cut,
           y = price)) +
  geom_boxplot(outlier.shape = NA,
               width = 0.25,
               fill = "#6CAEE0") +
  xlab(" ") +
  ggtitle("Distribution of diamond prices by cut",
          subtitle = "Source: ggplot2::diamonds data set") +
  coord_flip() +
  theme_bw()

# Violin plot (merges density plots with boxplots)
ggplot(data = diamonds, 
       aes(x = cut,
           y = price)) +
  geom_violin(fill = "#6CAEE0",
              adjust = 0.5) +
  coord_flip()

# Column plot from a dplyr pipeline
diamonds %>%
  group_by(cut) %>%
  summarise(median_price = median(price, na.rm = T)) %>% # Median is preferred to mean as the distribution is heavily skewed (see univariate section)
  ungroup() %>%
  ggplot(aes(x = cut,
             y = median_price)) +
  geom_col(width = 0.75,
           fill = "red",
           colour = "black") +
  geom_hline(yintercept = 0)

# Correlation plot
sapply(diamonds, function(x) is.numeric(x))

diamonds %>%
  select(1, 5, 6:10) %>% # Continuous variables
  cor() %>%
  ggcorrplot(hc.order = T,
             legend.title = "P",
             method = "square")

# Making publication-ready plots with additional ggplot2 functions
?theme_bw

# Scatterplot with additional information on diamond cut
ggplot(data = diamonds, 
       aes(x = carat,
           y = sqrt(price), # Note the coercion to sqrt to make the relationship more linear
           colour = cut)) +
  geom_jitter(alpha = 0.5) +
  xlab("carat") +
  ylab("sqrt(price)$") +
  scale_colour_discrete(name = " ") +
  ggtitle("Linear relationship between diamond price and carat",
          subtitle = "Source: ggplot2::diamonds data set") +
  theme_minimal()

# It's a bit difficult to distinguish the colours so let's facet wrap
ggplot(data = diamonds, 
       aes(x = carat,
           y = sqrt(price))) + # Note the coercion to sqrt to make the relationship more linear
  geom_jitter(alpha = 0.5) +
  facet_wrap(~cut, scales = "free_y") +
  geom_smooth(method = "lm") +
  ggtitle("Linear relationship between diamond price and carat with regression",
          subtitle = "Source: ggplot2::diamonds data set") +
  theme_bw()

# Same y-axis scale for comparison of gradients (rate of change)
ggplot(data = diamonds, 
       aes(x = carat,
           y = sqrt(price))) +
  geom_jitter(alpha = 0.5) +
  facet_wrap(~cut) +
  geom_smooth(method = "lm") + # Plot linear regression models for each cut group
  ggtitle("Linear relationship between diamond price and carat",
          subtitle = "Source: ggplot2::diamonds data set") +
  theme_bw()

# Diverging bars plot
mtcars$mpg_zscore <- round((mtcars$mpg - mean(mtcars$mpg)) / sd(mtcars$mpg), 2)  # Compute z-scores for mpg (normalisation)
mtcars$mpg_type <- if_else(mtcars$mpg_z < 0, "below", "above")  # Above or below average mpg indicator
mtcars <- mtcars[order(mtcars$mpg_z), ]  # Order data set by increasing mpg z-score
mtcars$car <- factor(mtcars$car, levels = mtcars$car)  # Convert to factor to retain sorted order in plot

# Diverging Barcharts
ggplot(mtcars, aes(x = car, 
                   y = mpg_zscore, 
                   label = mpg_zscore)) + 
  geom_bar(stat = "identity", 
           aes(fill = mpg_type), 
           width = 0.5)  +
  scale_fill_manual(name = "MPG", 
                    labels = c("Above average", "Below average"), 
                    values = c("above"="#00306A", "below"="#6CAEE0")) + 
  labs(subtitle = "Normalised miles per gallon from mtcars data set", 
       title = "Diverging barplot") + 
  xlab(" ") +
  coord_flip() +
  theme_bw() +
  theme(text = element_text(face = "bold"))

# Facetting with radar plots
ggplot(data = diamonds,
       aes(x = color,
           fill = color)) +
  geom_bar(colour = "black") +
  xlab(" ") +
  coord_polar() +
  facet_wrap(~cut) +
  theme_bw() +
  theme(text = element_text(face = "bold",
                            family = "courier")) +
  ggtitle("Diamond colour frequency by cut",
          subtitle = "Source: ggplot2::diamonds data set") +
  guides(fill = F)


## INTERACTIVE DATA VISUALISATION

# Sankey Network to display flow or distribution
# Sankey code
nodes = data.frame("name" = 
                     c("CALLSTAR", #0
                       "Switcher", #1
                       "Field Agents", #2 
                       "Online", #3
                       "Inbound", #4
                       "Outbound", #5
                       "Developer", #6
                       "Unavailable", #7
                       "Single product", #8
                       "Dual product", #9
                       "Triple product", #10
                       "Contract", #11
                       "0-1 year", #12
                       "1-3 year", #13
                       ">3 year", #14
                       "Zero traits", #15
                       "One traits", #16
                       "Two traits", #17
                       "Three traits", #18
                       "VIP")) #19

links = as.data.frame(matrix(c(
  0, 8, 15391,
  0, 9, 16782,
  0, 10, 18110,
  0, 11, 189,
  1, 8, 112,
  1, 9, 13845,
  1, 10, 4179,
  1, 11, 298,
  2, 8, 520,
  2, 9, 20360, 
  2, 10, 23209, 
  2, 11, 2900, 
  3, 8, 653,
  3, 9, 8281,
  3, 10, 5141,
  3, 11, 344,
  4, 8, 2817,
  4, 9, 5029,
  4, 10, 7529,
  4, 11, 32,
  5, 8, 37,
  5, 9, 209,
  5, 10, 1325,
  5, 11, 33,
  6, 8, 781,
  6, 9, 4706,
  6, 10, 4268,
  6, 11, 222,
  7, 8, 103603,
  7, 9, 99484,
  7, 10, 50956,
  7, 11, 55,
  8, 12, 11231,
  8, 13, 13179,
  8, 14, 100735,
  9, 12, 38657,
  9, 13, 41396,
  9, 14, 102526,
  10, 12, 33534,
  10, 13, 41336,
  10, 14, 58587,
  11, 12, 252,
  11, 13, 325,
  11, 14, 362,
  12, 15, 32084,
  12, 16, 22566,
  12, 17, 33371,
  12, 18, 4777,
  13, 15, 32084,
  13, 16, 47977,
  13, 17, 33371,
  13, 18, 66555,
  14, 15, 44168,
  14, 16, 37997,
  14, 17, 33371,
  14, 18, 4444,
  15, 19, 4994,
  16, 19, 22311,
  17, 19, 564,
  18, 19, 10198),
  byrow = T, 
  ncol = 3))

names(links) = c("source", "target", "value")

sankeyNetwork(Links = links, 
              Nodes = nodes,
              Source = "source", 
              Target = "target",
              Value = "value", 
              NodeID = "name",
              fontSize= 12,
              fontFamily = "Calibri",
              nodeWidth = 25)

# dygraphs is an open-source JavaScript charting library. The R package provides an interface to dygraphs.
# Very clean interactive graphics which can be embedded beautifully into reports, webpages and dashboards.
data(AirPassengers)
AirPassengers
class(AirPassengers)

# Static time-series plot
plot(AirPassengers)

# Interactive time-series dygraph 
# Time-slicer and embedded data are excellent features
dygraph(AirPassengers)

# Note how it can be used with dplyr's pipe operator
dygraph(AirPassengers) %>%
  dyRangeSelector()

# Modify and finalise for presentation
dygraph(AirPassengers,
        main = "Monthly Airline Passenger Numbers 1949-1960") %>%
  dyLegend(show = "always",
           labelsSeparateLines = F,
           width = 500) %>%
  dyOptions(drawGrid = T) %>%
  dySeries("V1", label = "passengers") %>%
  dyAxis("y", label = "passengers",
         valueFormatter = 'function(d){return d.toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g, ",");}',
         axisLabelFormatter = 'function(d){return d.toString().replace(/\\B(?=(\\d{3})+(?!\\d))/g, ",");}',
         axisLabelWidth = 70) %>%
  dyEvent("1960-01-01", "Some event", 
          labelLoc = "bottom")


###########################################################################
## PART 3: Q & A (10 min) 
###########################################################################

paste(my_name, "would like to thank you for your time and hopes that you have found this R workshop interesting.")

## Useful resources:

# R for Data Science (book)
# Practical Statistics for Data Scientists (book)
# citation("ggplot2") (book)
# StackOverflow (community website)
# DataCamp (online learning)
# R MeetUps (R Generation, Data Chats in a Pub, Dublin Data Science)

